# Project Repo

Summary: This is the root overview for the product repo. Use this page to explain what the product is, which app(s) live in this repo, how the repo is structured, and where a new agent or human should start reading.
