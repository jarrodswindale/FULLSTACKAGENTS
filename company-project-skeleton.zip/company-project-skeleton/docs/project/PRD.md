# Product Requirements Document

Summary: This page explains the user problem, goals, non-goals, target audience, feature scope, flows, acceptance criteria, and release priorities for the project.
