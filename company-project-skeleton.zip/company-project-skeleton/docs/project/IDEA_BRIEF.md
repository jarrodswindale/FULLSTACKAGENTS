# Idea Brief

Summary: This page captures the original idea, target user, problem statement, desired outcome, constraints, and initial assumptions before deeper discovery starts.
