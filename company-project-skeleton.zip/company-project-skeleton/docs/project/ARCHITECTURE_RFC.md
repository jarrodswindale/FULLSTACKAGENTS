# Architecture RFC

Summary: This page describes the current project architecture, including system boundaries, data flow, state ownership, route/screen structure, major risks, and implementation strategy.
