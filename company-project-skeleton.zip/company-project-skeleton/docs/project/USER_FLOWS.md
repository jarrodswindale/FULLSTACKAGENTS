# User Flows

Summary: This page maps the intended user journeys, screen transitions, and key decision points so product, design, and engineering stay aligned on behavior.
