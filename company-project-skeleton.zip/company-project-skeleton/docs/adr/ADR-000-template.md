# ADR Template

Summary: Use this template for each major architecture decision. It should capture context, options considered, the chosen decision, consequences, and follow-up actions.
