# ADR Index

Summary: This page lists all Architecture Decision Records and explains how to create, review, and supersede architecture decisions over time.
