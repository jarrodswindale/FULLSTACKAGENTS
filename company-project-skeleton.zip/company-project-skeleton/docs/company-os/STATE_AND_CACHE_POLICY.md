# State and Cache Policy

Summary: This page defines how local state, server state, caching, invalidation, sync, offline behavior, and stale data handling should work across apps.
