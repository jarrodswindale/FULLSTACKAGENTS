# Product Principles

Summary: This page defines the product-level rules for what good product thinking looks like in this company, including clarity of problem, user value, scope discipline, and decision-making standards.
