# Testing Standard

Summary: This page describes the required testing layers, QA expectations, simulator/browser coverage, artifact requirements, and which tools should be used.
