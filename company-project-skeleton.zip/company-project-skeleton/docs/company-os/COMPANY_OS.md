# Company OS

Summary: This page defines the overall company operating system: agent hierarchy, gates, approvals, branch strategy, QA policy, metrics, and how work moves from idea to release.
