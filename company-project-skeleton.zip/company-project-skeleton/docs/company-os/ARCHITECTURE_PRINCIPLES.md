# Architecture Principles

Summary: This page defines the high-level technical rules for building products in this company, including modularity, boundaries, state ownership, scalability, and maintainability expectations.
