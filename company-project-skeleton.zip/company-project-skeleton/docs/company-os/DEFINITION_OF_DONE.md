# Definition of Done

Summary: This page explains what must be true before a task, feature, milestone, or release can be considered complete.
