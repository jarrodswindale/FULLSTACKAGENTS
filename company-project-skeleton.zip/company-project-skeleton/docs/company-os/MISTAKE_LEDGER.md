# Mistake Ledger

Summary: This page stores recurring mistakes, why they happened, how they were fixed, and what rule or checklist change should prevent them in future projects.
