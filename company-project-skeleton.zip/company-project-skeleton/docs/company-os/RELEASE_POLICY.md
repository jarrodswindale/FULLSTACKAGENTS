# Release Policy

Summary: This page explains how work moves from integration to release, which approvals are required, how rollback works, and what release evidence must exist.
