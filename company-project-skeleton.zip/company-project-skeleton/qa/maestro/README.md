# Maestro QA

Summary: This page explains how mobile UI automation is structured, where flow files live, which devices are targeted, and how artifacts are captured.
