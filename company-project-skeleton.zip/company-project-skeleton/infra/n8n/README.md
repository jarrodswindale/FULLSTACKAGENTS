# n8n

Summary: This page documents automation workflows for notifications, approvals, reminders, and integration logic between Paperclip, GitHub, Telegram, and the business database.
