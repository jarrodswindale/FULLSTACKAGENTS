# Supabase

Summary: This page describes the database structure, schemas, tables, auth assumptions, storage usage, and business-memory/event logging conventions.
