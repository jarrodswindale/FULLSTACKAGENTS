---
name: Feature request
about: Plan a new feature
---

# Summary
This issue template is for features. Capture the user problem, desired outcome, scope, success criteria, dependencies, risks, and acceptance criteria.
