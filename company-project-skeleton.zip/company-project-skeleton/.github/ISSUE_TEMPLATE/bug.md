---
name: Bug report
about: Report a defect
---

# Summary
This issue template is for bugs. Capture the problem, reproduction steps, expected result, actual result, environment, screenshots, and severity.
