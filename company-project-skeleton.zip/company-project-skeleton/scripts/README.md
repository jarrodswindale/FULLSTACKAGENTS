# Scripts

Summary: This page documents reusable project scripts for setup, linting, formatting, code generation, test runs, release prep, and maintenance tasks.
