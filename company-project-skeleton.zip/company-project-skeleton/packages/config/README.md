# Config Package

Summary: This page explains shared configuration used across apps and services, such as linting, TypeScript settings, environment schemas, and runtime config helpers.
