# Types Package

Summary: This page defines shared TypeScript types, schemas, DTOs, and interfaces used across apps and services.
