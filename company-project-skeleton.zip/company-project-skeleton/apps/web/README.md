# Web App

Summary: This page explains what lives in the web app, how to run it, what web-specific constraints exist, and how it shares logic or UI with the mobile app.
