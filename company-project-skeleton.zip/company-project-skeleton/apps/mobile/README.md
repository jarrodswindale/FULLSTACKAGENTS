# Mobile App

Summary: This page explains what lives in the mobile app, how to run it, which platform decisions were made, and which folders or features are specific to Expo / React Native / iOS.
