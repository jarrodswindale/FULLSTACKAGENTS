# Paperclip Skills

Summary: This page stores company-level skills, policies, checklists, and injected knowledge that agents should use during discovery, planning, building, and QA.
