# Paperclip Templates

Summary: This page stores reusable issue templates, handoff templates, gate summaries, standup formats, and structured payload templates for the operating system.
