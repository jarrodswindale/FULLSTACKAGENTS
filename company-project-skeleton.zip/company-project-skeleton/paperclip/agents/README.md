# Paperclip Agents

Summary: This page lists the available agent roles, what each one is allowed to do, when they wake up, and which types of issues they may own.
